import { Component, ViewChild } from '@angular/core';
import {Events, ModalController, Nav, NavController, Platform} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import * as WC from 'woocommerce-api';
import {ProductsByCategoryPage} from "../pages/products-by-category/products-by-category";
import {SignupPage} from "../pages/signup/signup";
import {HomePage} from "../pages/home/home";
import { Storage } from '@ionic/storage';
import {LoginPage} from "../pages/login/login";
import {CartPage} from "../pages/cart/cart";


@Component({
  templateUrl: 'app.html'
})
export class MyApp {

  @ViewChild('content') childNavCtrl: Nav;
  rootPage: any = HomePage;

  WooCommerce: any;
  categories: any[];
  loggedIn: boolean;
  user: any;


  constructor(
              // public navCtrl: NavController,
              public platform: Platform, public statusBar: StatusBar,
              public splashScreen: SplashScreen,
              public storage: Storage,
              public modalCtrl: ModalController,
              private events: Events) {

    this.categories = [];
    this.user = {};

    this.WooCommerce = WC({
      url: "http://lifestylefurniture.co/lelebaba",
      consumerKey: "ck_8810abbfd1cb8d6c0573757dd61b35b059c2157c",
      consumerSecret: "cs_6b97edf0b39010475b209826ae123a4354258fc0"
    });


    this.WooCommerce.getAsync("products/categories").then((data) => {
      console.log('Categories',JSON.parse(data.body).product_categories);

      let temp: any[] = JSON.parse(data.body).product_categories;

      for (let i = 0; i < temp.length; i++) {
        if (temp[i].parent == 0) {

          temp[i].subCategories = [];

          if (temp[i].slug == "clothing") {
            temp[i].icon = "shirt";
          }
          if (temp[i].slug == "music") {
            temp[i].icon = "musical-notes";
          }
          if (temp[i].slug == "posters") {
            temp[i].icon = "images";
          }

          this.categories.push(temp[i]);
        }
      }

      //Groups Subcategories

      for (let i = 0; i < temp.length; i++){
        for (let j = 0; j < this.categories.length; j++){
          //console.log("Checking " + j + " " + i)
          if(this.categories[j].id == temp[i].parent){
            this.categories[j].subCategories.push(temp[i]);
          }
        }
      }



    }, (err) => {
      console.log(err)
    });


    this.storage.ready().then(() => {
      this.storage.get("userLoginInfo").then((userLoginInfo) => {

        if (userLoginInfo != null) {

          console.log("User logged in...");
          this.user = userLoginInfo.user;
          console.log(this.user);
          this.loggedIn = true;
        }
        else {
          console.log("No user found.");
          this.user = {};
          this.loggedIn = false;
        }

      })
    })

  }// end of CONSTRUCTOR




  ionViewDidEnter() {

    console.log("User logged in...");
    this.storage.ready().then(() => {
      this.storage.get("userLoginInfo").then((userLoginInfo) => {

        if (userLoginInfo != null) {

          console.log("User logged in...");
          this.user = userLoginInfo.user;
          console.log(this.user);
          this.loggedIn = true;
        }
        else {
          console.log("No user found.");
          this.user = {};
          this.loggedIn = false;
        }

      })
    })


  }

  openCategoryPage(category) {

    this.childNavCtrl.setRoot(ProductsByCategoryPage, { "category": category });

  }


  openPage(pageName: string) {

    if (pageName == "signup") {
      this.childNavCtrl.push(SignupPage);
    }
    if (pageName == "login") {
      this.childNavCtrl.push(LoginPage);
    }
    if (pageName == 'logout') {
      this.storage.remove("userLoginInfo").then(() => {
        this.user = {};
        this.loggedIn = false;
      })
    }
    if (pageName == 'cart') {
      let modal = this.modalCtrl.create(CartPage);
      modal.present();
    }

  }




}
